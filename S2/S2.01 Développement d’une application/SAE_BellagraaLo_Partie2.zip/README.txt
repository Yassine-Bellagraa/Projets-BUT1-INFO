Cette archive contient les réponses à la partie 1 de la SAE Java.

Vous trouverez dans cette archive  3 répertoires :
- Le répertoire diagramme UML : un diagramme UML qui est la synthèse des questions de la partie I. UML
- Le répertoire Sources Java (.java) : l'ensemble des classes qui sont la synthèse des questions de la partie II. Java
- Le repertoire Exécutables (.class) : l'ensemble des classes compilés dans le cas où vous auriez un problème à compiler les fichiers .java


Voici nos code INE si besoin : 
0JYJQV06MZ7 (Faty Lo)
070466097DJ (Yassine Bellagraa)